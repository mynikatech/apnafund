state_bucket_name = "apnafund-terraform-backend"
state_lock_table_name = "terraform-locks"
config_bucket = "apnafund-config"
region = "ap-south-1"
jenkins_deploy_role_name = "ApnaFundJenkinsDeployRole"
create_jenkins_access_key = true